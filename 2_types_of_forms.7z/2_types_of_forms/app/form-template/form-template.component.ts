import { Component, OnInit } from '@angular/core';
import { Hero } from './hero.model';

@Component({
  selector: 'app-form-template',
  templateUrl: './form-template.component.html',
  styleUrls: ['./form-template.component.css']
})
export class FormTemplateComponent implements OnInit {
  powers = ['Really Smart','Super Flexible','Super Hot','Weather Changer'];
  model = new Hero(18, 'DR IQ',this.powers[0], 'Chuck overstreet');
  submitted = false;
   myHero =  new Hero(42, 'SkyDog',
                       'Fetch any object at any distance',
                       'Leslie Rollover');

  constructor() { }
  
  onSubmit(){ this.submitted= true ; console.log(this.model);
  };
  
  newHero() {
    this.model = new Hero(42, '', '');
  }

  ngOnInit(): void {
  }

}
