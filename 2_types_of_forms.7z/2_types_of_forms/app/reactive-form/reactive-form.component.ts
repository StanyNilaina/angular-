import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})
export class ReactiveFormComponent implements OnInit {
  profileForm = new FormGroup({
    firstname: new FormControl(''),
    lastname: new FormControl(''),
    address: new FormGroup({
      street: new FormControl(''),
      city: new FormControl(''),
      state: new FormControl(''),
      zip: new FormControl('')
    })
  });
  constructor() { }

  onSubmit() {
    // TODO: Use EventEmitter with form value
    console.table(this.profileForm.value);
  }

  
      
updateProfile() {
  this.profileForm.patchValue({
    firstname: 'Nancy',
    address: {
      street: '123 Drew Street'
    }
  });
}


  ngOnInit(): void {
  }

}

//SI ON VEUT UTILISER LE FORMBUILDER RECOMMANDE//
/*
 
      
import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';

export class ReactiveFormComponent {
  profileForm = this.fb.group({
    firstName: ['',Validators.required],
    lastName: ['',Validators.required],
    address: this.fb.group({
      street: ['',Validators.required],
      city: ['',Validators.required],
      state: ['',Validators.required],
      zip: ['']
    }),
  });

  constructor(private fb: FormBuilder) { }
}*/